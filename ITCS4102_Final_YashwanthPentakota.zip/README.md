# ITCS 4102 Final Project - Yashwanth Pentakota

## Project Title
**Exploring Functional and Imperative Paradigms Through Haskell and Python**

## Overview
This project compares the functional programming paradigm (Haskell) and the imperative paradigm (Python) by implementing and analyzing a set of common algorithms.

## Algorithms Implemented
- Bubble Sort
- Merge Sort
- Factorial (Recursive)
- Fibonacci (Recursive & Iterative)
- Binary Tree Traversal (Inorder, Preorder, Postorder)

## Folder Structure
- `Python_Code/` — Python implementations
- `Haskell_Code/` — Haskell implementations
- `Screenshots/` — Output screenshots and benchmark charts
- `Final_Report_YashwanthPentakota.docx` — Final report

## Tools & Technologies
- Python 3.x
- Haskell (GHC)
- VS Code
- Git & GitHub
- `matplotlib` (for Python visualizations)

## How to Run
### Python
```bash
cd Python_Code
python bubble_sort.py
```

### Haskell
```bash
cd Haskell_Code
runhaskell BubbleSort.hs
```

## Author
**Yashwanth Pentakota**  
UNC Charlotte - ITCS 4102

## License
This project is for academic purposes.
