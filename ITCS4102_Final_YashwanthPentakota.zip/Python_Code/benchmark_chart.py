import time
import matplotlib.pyplot as plt
import random

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    while left and right:
        if left[0] <= right[0]:
            result.append(left.pop(0))
        else:
            result.append(right.pop(0))
    result.extend(left or right)
    return result

sizes = [100, 200, 400]
bubble_times = []
merge_times = []

for size in sizes:
    data = [random.randint(1, 1000) for _ in range(size)]

    start = time.time()
    bubble_sort(data.copy())
    bubble_times.append(time.time() - start)

    start = time.time()
    merge_sort(data.copy())
    merge_times.append(time.time() - start)

plt.plot(sizes, bubble_times, label='Bubble Sort')
plt.plot(sizes, merge_times, label='Merge Sort')
plt.xlabel('Input Size')
plt.ylabel('Execution Time (s)')
plt.title('Bubble Sort vs Merge Sort Benchmark')
plt.legend()
plt.savefig('../Screenshots/benchmark_chart.png')
plt.show()
