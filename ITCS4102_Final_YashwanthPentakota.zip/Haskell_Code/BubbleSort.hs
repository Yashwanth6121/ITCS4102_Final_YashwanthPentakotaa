bubbleSort :: (Ord a) => [a] -> [a]
bubbleSort [] = []
bubbleSort xs = bubbleSort (init bubbled) ++ [last bubbled]
  where
    bubbled = bubble xs
    bubble [x] = [x]
    bubble (x:y:zs)
      | x > y     = y : bubble (x:zs)
      | otherwise = x : bubble (y:zs)

main = print $ bubbleSort [64, 34, 25, 12, 22, 11, 90]
