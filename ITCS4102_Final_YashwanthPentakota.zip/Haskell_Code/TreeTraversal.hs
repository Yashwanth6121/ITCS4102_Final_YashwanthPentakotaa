data Tree a = Empty | Node a (Tree a) (Tree a)

inorder :: Tree a -> [a]
inorder Empty = []
inorder (Node x l r) = inorder l ++ [x] ++ inorder r

preorder :: Tree a -> [a]
preorder Empty = []
preorder (Node x l r) = [x] ++ preorder l ++ preorder r

postorder :: Tree a -> [a]
postorder Empty = []
postorder (Node x l r) = postorder l ++ postorder r ++ [x]

sampleTree :: Tree Int
sampleTree = Node 1 (Node 2 (Node 4 Empty Empty) (Node 5 Empty Empty))
                    (Node 3 Empty Empty)

main = do
  putStrLn "Inorder:"
  print $ inorder sampleTree
  putStrLn "Preorder:"
  print $ preorder sampleTree
  putStrLn "Postorder:"
  print $ postorder sampleTree
