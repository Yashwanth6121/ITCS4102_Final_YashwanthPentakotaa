fibonacci :: Integer -> Integer
fibonacci 0 = 0
fibonacci 1 = 1
fibonacci n = fibonacci (n - 1) + fibonacci (n - 2)

fibonacciIter :: Integer -> Integer
fibonacciIter n = fibIter n 0 1
  where
    fibIter 0 a _ = a
    fibIter n a b = fibIter (n - 1) b (a + b)

main = do
  print $ fibonacci 10
  print $ fibonacciIter 10
